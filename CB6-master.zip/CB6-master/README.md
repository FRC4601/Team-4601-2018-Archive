# CB6

It's time to...
LEVEL UP!

Robot: Melman?

# Todo
- ~~Get a Roborio~~
- ~~Make some janky terrible code~~
- ~~Make it work~~
- ~~??~~
- Profit (I'm still wating on this part)
